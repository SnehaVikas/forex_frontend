import React from 'react';
import axios from 'axios';
import Header from './Header';
import Title from './Title';
import Footer from './Footer';



function Index() {
    return (

        <div>
            <Header />
            <Title/>
            <Footer/>
        </div>
    )
}
export default Index;