import React from "react";

function Admin_Footer() {
	return (
		// <footer id="footer" class="bg-dark text-white d-flex-column text-center">
			<div class="container p-4" >
				<section class="">

<div className='text-center p-4' style={{ backgroundColor: 'rgba(0, 0, 0, 0.2)',marginTop:'5%' }}>
								<a className='text-reset fw-bold' href='https://mdbootstrap.com/' style={{color:'black'}}>
					Forex @ 2023 Copyright

				</a>
			
			</div>
        
            </section>
            </div>
		// </footer>
        )
    }
    export default Admin_Footer;
    
