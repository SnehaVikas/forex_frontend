import React from 'react';
import axios from 'axios';
import Admin from './Admin';
import Title from './Title';
import Admin_Footer from './Admin_Footer';



function Admin_Index() {
    return (

        <div>
            <Admin />
            <Title/>
            <Admin_Footer/>
        </div>
    )
}
export default Admin_Index;