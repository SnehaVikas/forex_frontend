import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {TextField,Button, MenuItem} from '@mui/material';
import { Container } from "@mui/system";
import { Link } from "react-router-dom";
import Subheader from "./Subheader";
import Footer from "./Footer";

function SaveUserBankDetails()
{
    const [bankId,setBankId] = useState("");
     const[name,setName]=useState(""); 
     const[bankName,setBankName]=useState(""); 
     const[accountNumber,setAccountNumber]=useState("");
     const[ifscCode,setIfscCode]=useState("");
     const[contactNumber,setContactNumber]=useState("");
     const [formErrors, setFormErrors] = useState({});


     

     const handleSubmit = () => {
        let errors = {};
        if (!name) {
            errors['NameError'] = "Name is required."
        }
         if (!accountNumber) {
            errors['AccountNumberError'] = "Account Number  is required."
        }
       
        if (!ifscCode) {
            errors['IFSCCodeError'] = "IFSC Code is required."
        } 
        if (!bankName) {
            errors['bankNameError'] = "Bank Name is required."
        } 
        if (!contactNumber) {
            errors['contactNumberError'] = "Contact Number is requred."
        } 
        // if (!contactNumber <= 10) {

        //     errors['contactNumberError'] = "Invalid Mobile no(Only 10 digit)/ characters not allowed."
            
        //      }


        setFormErrors(errors);
        const noErrors = Object.keys(errors).length === 0;
        // if no errors then  call the api
        if (noErrors) {

            const payload = {
                acHolderName:name,
                bankName: bankName,
                accountNumber:accountNumber,
                ifscCode:ifscCode,
                contactNumber:contactNumber
        


            }
            
            axios.post("http://localhost:8081/UserBankDetails/save", payload).then(resp => alert("Bank Details Saved: "+resp.data.id));
        }
     }

    
    return(
        <>
            {<div>
            <Subheader/>

            <Footer/>
            
        </div> }
        <div class="row" style={{marginTop:'5%'}}>
        <Container maxWidth="sm" style={{display:'flex',justifyContent:"center",alignItems:"center",height:"100vh"}}>
          
         <form  style={{ display:"flex",marginTop:"-50%" ,flexDirection:"column",minWidth:"300px",maxWidth:"500px",height:"150px"}}>
         <h2>Bank Details</h2>

         
       
         
          <TextField
             label="Account Holder Name" value={name} onChange={(event)=>setName(event.target.value)}required
             error={!!formErrors.NameError} helperText={formErrors.NameError}
             style={{marginBottom:"10px"}}>
        </TextField>
          
          <TextField
             label="Bank Name " value={bankName} onChange={(event)=>setBankName(event.target.value)}required
             error={!!formErrors.bankNameError} helperText={formErrors.bankNameError}
             style={{marginBottom:"10px"}}></TextField>
          
          <TextField
             label="Account  Number " value={accountNumber} onChange={(event)=>setAccountNumber(event.target.value)}required
             error={!!formErrors.AccountNumberError} helperText={formErrors.AccountNumberError}
             style={{marginBottom:"10px"}}></TextField>
          
          <TextField
             label="IFSC Code " value={ifscCode} onChange={(event)=>setIfscCode(event.target.value)}required
             error={!!formErrors.IFSCCodeError} helperText={formErrors.IFSCCodeError}
             style={{marginBottom:"10px"}}></TextField>

              <TextField
             label="Contact Number" value={contactNumber} onChange={(event)=>setContactNumber(event.target.value)}required
             error={!!formErrors.contactNumberError} helperText={formErrors.contactNumberError}
             style={{marginBottom:"10px"}}></TextField>
           
          
           
           
          
          <div style={{display:"flex",justifyContent:"space-between"}}>
          <Button onClick ={handleSubmit} type="submit" variant="contained" color="primary" fullWidth >Submit</Button>
          </div>
          <div style={{marginTop:"5%"}}>
            <Link to="/"><Button type="button"variant="contained" color="secondary" fullWidth>Cancel</Button></Link>
        
        </div>
       
       
         </form>
         
         </Container>  
    </div>
  
</>);

}
export default SaveUserBankDetails;